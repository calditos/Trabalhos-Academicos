package aulaluta;
public class Combate {
   
  

    public static void main(String[] args) {
       Lutador l []= new Lutador[6];
       new  Lutador("Joao Corinthiano","Brasil",31,11,2,1,1,78f,68,9f);
       l.apresentar();
       l.status();
    }
    }
      
        
    }
    
}
