package poo_herança_polimorfismo;

public class Professor extends Pessoa{
    
    private String especialidade;
    private float salario;
    
    public void receberAum(){
        //metodo
    }
    public String getEspecialidade() {
        return especialidade;
    }
    public void setEspecialidade(String es) {
        this.especialidade = es;
    }
    public float getSalario() {
        return salario;
    }
    public void setSalario(float sa) {
        this.salario = sa;
    }
    
    @Override
    public void status() {
        System.out.println("---------------- Professor ----------------");
        System.out.println("- Nome: " + getNome());   
        System.out.println("- Especialidade: " + getEspecialidade()); 
        System.out.println("- Salario: " + getSalario());
    }
}
