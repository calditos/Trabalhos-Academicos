package poo_herança_polimorfismo;

public class Pessoa {
    private String nome;

    public String getNome() {
        return nome;
    }
    public void setNome(String no) {
        this.nome = no;
    }
    public void status(){ 
        System.out.println("----------------- Pessoa ------------------"); 
        System.out.println("- Nome: " + getNome());
    }
}
