package poo_herança_polimorfismo;

public class Funcionario extends Pessoa{

    private String setor;
    private double trabalhando;
    
    public void mandarTrabalhao(){
        //metodo
    }
    public String getSetor() {
        return setor;
    }
    public void setSetor(String se) {
        this.setor = se;
    }
    public double getTrabalhando() {
        return trabalhando;
    }
    public void setTrabalhando(double tr) {
        this.trabalhando = tr;
    }
    
    @Override
    public void status() {
        System.out.println("--------------- Funcionario ---------------"); 
        System.out.println("- Nome: " + getNome());
        System.out.println("- Setor: " + getSetor()); 
        System.out.println("- Trabalhando: " + getTrabalhando());
    }    
}
