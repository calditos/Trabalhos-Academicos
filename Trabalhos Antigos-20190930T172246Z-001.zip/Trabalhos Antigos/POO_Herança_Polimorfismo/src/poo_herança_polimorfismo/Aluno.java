package poo_herança_polimorfismo;

import java.awt.BorderLayout;

public class Aluno extends Pessoa{
    
    private int matr;
    private String curso;
    
    public void cancelarMatr(){
        //metodo
    }
    public int getMatr() {
        return matr;
    }
    public void setMatr(int ma) {
        this.matr = ma;
    }
    public String getCurso() {
        return curso;
    }
    public void setCurso(String cu) {
        this.curso = cu;
    }

    @Override
    public void status() {
        System.out.println("------------------ Aluno ------------------"); 
        System.out.println("- Nome: " + getNome());   
        System.out.println("- Matricula: " + getMatr()); 
        System.out.println("- Curso: " + getCurso());  
    }
      
}
