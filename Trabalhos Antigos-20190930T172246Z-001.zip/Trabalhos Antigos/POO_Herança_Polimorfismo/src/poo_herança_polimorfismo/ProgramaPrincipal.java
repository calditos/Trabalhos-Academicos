package poo_herança_polimorfismo;

public class ProgramaPrincipal {

    public static void main(String[] args) {
        // criando objetos em suas respectivas classes
        Pessoa p1 = new Pessoa();
        Aluno p2 = new Aluno();
        Professor p3 = new Professor();
        Funcionario p4 = new Funcionario();
        
        // metodo "setNome" herdado da classe mãe
        p1.setNome("Pedro");
        p2.setNome("Maria");
        p3.setNome("Cláudio");
        p4.setNome("Fabiana");
        
        // atribui valores através do metodo "set" em suas respectivas classes
        p2.setCurso("Informárica");
        p3.setSalario(2500.75f);
        p4.setSetor("Estoque");
        
        // metodo Polimorfismo, herda o metodo porem sobrescreve em cada classe
        // através da Sobreposição
        p1.status();
        p2.status();
        p3.status();
        p4.status();
               
    }   
}


